# jar2dex



```shell
dx --dex --output="out.dex" "source.jar"
```

