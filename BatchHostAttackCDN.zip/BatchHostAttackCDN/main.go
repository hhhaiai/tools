package main

import (
	"bufio"
	"crypto/tls"
	"github.com/yezihack/colorlog"
	"math/rand"
	"net/http"
	"os"
	"sync"
	"time"
)

func readLine(r *bufio.Reader) (string, error) {
	line, isprefix, err := r.ReadLine()
	for isprefix && err == nil {
		var bs []byte
		bs, isprefix, err = r.ReadLine()
		line = append(line, bs...)
	}
	return string(line), err
}

func ReadFile(filename string) []string {
	f, _ := os.Open(filename)
	r := bufio.NewReader(f)
	dataList := []string(nil)

	for {
		data, err := readLine(r)
		if err != nil {
			break
		}
		dataList = append(dataList, data)
	}
	return dataList

}

func CheckReq(Host string, target string, userAgent string, group *sync.WaitGroup, resrultTarget *[]string) {
	url := "http://" + target + ":443"

	var client *http.Client = &http.Client{
		Transport: &http.Transport{
			TLSClientConfig: &tls.Config{InsecureSkipVerify: true}, //忽略证书校验
		},
		Timeout: time.Second * 5,
	}
	//_ = client

	req, _ := http.NewRequest("GET", url, nil)
	req.Host = Host
	req.Header.Add("User-Agent", userAgent)

	//resp, reqErr := http.DefaultClient.Do(req)
	resp, reqErr := client.Do(req)
	if reqErr != nil {
		//colorlog.Error("请求错误: %s", reqErr.Error())
		defer group.Done()
		return
	}
	//respHeader := resp.Header.Get("content-type")
	if resp.StatusCode == 200 {
		colorlog.Info("%s 该域名源服务器可能的IP地址: %s", Host, target)
		*resrultTarget = append(*resrultTarget, target)
		defer group.Done()
	} else {
		defer group.Done()
		return
		//colorlog.Warn("未查找到该网站的源IP: %s", target)
	}
	defer group.Done()
	return

}

func main() {
	var group sync.WaitGroup
	resultTarget := []string(nil)
	userAgentList := ReadFile("User-Agent.txt")
	targetList := ReadFile("target.txt")
	targeDomaintList := ReadFile("targetDomain.txt")
	group.Add(len(targetList) * len(targeDomaintList))
	for _, targetDomain := range targeDomaintList {
		for _, target := range targetList {
			go CheckReq(targetDomain, target, userAgentList[rand.Intn(len(userAgentList))], &group, &resultTarget)
		}
	}

	group.Wait()
}
