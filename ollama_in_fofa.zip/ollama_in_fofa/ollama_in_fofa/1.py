import base64
import requests
import json
import time

# FOFA API 配置
FOFA_EMAIL = "2078681762@qq.com"  # 替换为你的 FOFA 邮箱
FOFA_KEY = "83a41d0167ff4f0faa4d716de0f1c0f2"  # 替换为你的 FOFA API 密钥
BASE_URL = "https://fofa.info/api/v1/search/next"  # FOFA 连续翻页接口

# 搜索参数
query = '"Ollama is running" && "HTTP/1.1 200 OK"'  # FOFA 查询语法
fields = "host,ip,port,country"  # 返回 IP、端口、国家
size = 10  # 每次请求的最大结果数（最大 10000）
next_id = None  # 用于翻页

# 构造查询参数
params = {
    "email": FOFA_EMAIL,
    "key": FOFA_KEY,
    "qbase64": base64.b64encode(query.encode("utf-8")).decode("utf-8"),  # Base64 编码
    "fields": fields,
    "size": size,
}

# 获取初始数据
all_results = []

while True:
    if next_id:
        params["next"] = next_id  # 加上翻页参数

    try:
        # 发送请求获取数据
        response = requests.get(BASE_URL, params=params)
        if response.status_code == 200:
            data = response.json()
            if data["error"]:
                print(f"FOFA 返回错误: {data['errmsg']}")
                break
            results = data["results"]
            next_id = data.get("next", None)  # 获取下一个翻页ID

            # 如果没有下一页数据，结束循环
            if not next_id:
                print("没有更多数据，停止获取数据。")
                break

            # 处理获取的每一条结果
            for result in results:
                ip = result[0]
                port = result[1]
                country = result[3]  # 获取国家字段
                model = "无模型数据"  # 默认模型数据

                # 可以进一步补充模型信息（例如通过 Ollama API 获取）
                # 这里将简化为仅返回 IP、端口和国家信息

                result_data = {
                    "ip": ip,
                    "port": port,
                    "model": model,
                    "country": country
                }
                all_results.append(result_data)

            print(f"成功获取 {len(results)} 条数据")
        else:
            print(f"请求失败，状态码: {response.status_code}")
            break

        # 设置延迟，避免请求过于频繁
        time.sleep(1)

    except Exception as e:
        print(f"请求过程中发生错误: {e}")
        break

# 保存所有结果到 JSON 文件
with open("models_with_country.json", "w", encoding="utf-8") as f:
    json.dump(all_results, f, ensure_ascii=False, indent=4)
print("所有数据已保存为 models_with_country.json")
