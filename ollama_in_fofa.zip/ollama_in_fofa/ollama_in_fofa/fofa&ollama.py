import base64
import requests
import json

# FOFA API 配置
FOFA_EMAIL = "2078681762@qq.com"  # 替换为你的 FOFA 邮箱
FOFA_KEY = "83a41d0167ff4f0faa4d716de0f1c0f2"  # 替换为你的 FOFA API 密钥
BASE_URL = "https://fofa.info/api/v1/search/all"  # FOFA API 地址

# 搜索参数
query = '"Ollama is running" && "HTTP/1.1 200 OK"'  # FOFA 查询语法
fields = "ip,port,protocol,country,country_name,region,city,longitude,latitude"  # 更新为所有需要返回的字段
size = 50  # 每次请求的最大结果数（最大 10000）

# 构造请求 URL
params = {
    "email": FOFA_EMAIL,
    "key": FOFA_KEY,
    "qbase64": base64.b64encode(query.encode("utf-8")).decode("utf-8"),  # Base64 编码,  # 查询语句需要 Base64 编码
    "fields": fields,
    "size": size,
}

# 请求 FOFA API 获取 IP 地址和端口等信息
try:
    # 发送 GET 请求
    response = requests.get(BASE_URL, params=params)

    # 检查响应状态码
    if response.status_code == 200:
        data = response.json()
        if data["error"]:  # 检查是否有错误
            print(f"FOFA 返回错误: {data['errmsg']}")
        else:
            results = data["results"]
            print(f"共找到 {len(results)} 条结果:")

            all_models = []

            # 遍历 FOFA 返回的每个结果，获取 IP 和端口后进行 Ollama API 请求
            for result in results:
                ip = result[0]
                port = result[1]

                # 构建请求 Ollama API 的 URL
                ollama_url = f"http://{ip}:{port}/api/tags"

                try:
                    # 发送 GET 请求到 Ollama API
                    ollama_response = requests.get(ollama_url)

                    if ollama_response.status_code == 200:
                        # 解析 Ollama 返回的 JSON 数据
                        models = ollama_response.json()

                        # 将 FOFA 查询的结果和 Ollama 模型数据合并
                        result_data = {
                            "ip": ip,
                            "port": port,
                            "models": models
                        }
                        all_models.append(result_data)
                        print(f"成功获取 {ip}:{port} 的数据")
                    else:
                        print(f"请求失败，IP: {ip}:{port}，状态码: {ollama_response.status_code}")
                        print(f"错误信息: {ollama_response.text}")
                except Exception as e:
                    print(f"请求过程中发生错误，IP: {ip}:{port}，错误: {e}")

            # 将结果保存为 JSON 文件
            with open("爬虫/models.json", "w", encoding="utf-8") as f:
                json.dump(all_models, f, ensure_ascii=False, indent=4)
            print("所有模型数据已保存为 models.json")

    else:
        print(f"请求失败，状态码: {response.status_code}")
        print(f"错误信息: {response.text}")
except Exception as e:
    print(f"请求过程中发生错误: {e}")
