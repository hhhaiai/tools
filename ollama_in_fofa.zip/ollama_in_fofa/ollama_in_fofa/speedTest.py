import requests

# 服务器地址
url = "http://172.233.120.84:11434/api/generate"

# 请求数据
data = {
    "model": "qwen:latest",
    "prompt": "你好"
}

# 发送 POST 请求
response = requests.post(url, json=data, stream=True)

# 处理响应（流式输出）
for line in response.iter_lines():
    if line:
        print(line.decode("utf-8"))  # 解码并打印每一行
