from flask import Flask, render_template, request
import sqlite3

app = Flask(__name__)

# Database path
DB_PATH = "servers.db"

# Function to fetch data from database with pagination and sorting
def get_servers(page, per_page, sort_by, sort_order):
    # Calculate offset for pagination
    offset = (page - 1) * per_page

    # Connect to the database
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    # Validate sort column and order
    valid_columns = ['ip', 'port', 'country_name', 'region', 'name']
    if sort_by not in valid_columns:
        sort_by = 'ip'
    if sort_order not in ['asc', 'desc']:
        sort_order = 'asc'

    # Query to get servers with models, with pagination and sorting
    cursor.execute(f'''
        SELECT s.ip, s.port, s.country_name, s.region, m.name
        FROM servers s
        LEFT JOIN models m ON s.id = m.server_id
        ORDER BY {sort_by} COLLATE NOCASE {sort_order}  -- Case-insensitive letter sorting
        LIMIT ? OFFSET ?
    ''', (per_page, offset))

    # Get the rows
    rows = cursor.fetchall()

    # Close the connection
    conn.close()

    return rows

@app.route('/')
def index():
    # Get current page, page size, sorting parameters from request arguments (defaults if not present)
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 10, type=int)
    sort_by = request.args.get('sort_by', 'ip')  # Default to sorting by 'ip'
    sort_order = request.args.get('sort_order', 'asc')  # Default to ascending order

    # Fetch the servers with models data for the current page
    rows = get_servers(page, per_page, sort_by, sort_order)

    # Pass the data to the template
    return render_template('index.html', rows=rows, page=page, per_page=per_page, sort_by=sort_by, sort_order=sort_order)

if __name__ == "__main__":
    app.run(debug=True)
