import sqlite3
import requests
import json
import time


def delaytest(url, model, prompt):
    """
    调用 DeepSeek API 并处理流式响应
    """
    headers = {
        "Content-Type": "application/json"
    }
    payload = {
        "model": model,
        "prompt": prompt,
        "stream": True  # 启用流式响应
    }

    try:
        # 记录开始时间
        start_time = time.time()

        # 发送 POST 请求
        response = requests.post(url, json=payload, headers=headers, stream=True)

        # 初始化完整响应
        full_response = ""

        # 逐行处理流式响应
        for line in response.iter_lines():
            if line:
                # 解析 JSON 数据
                data = json.loads(line.decode('utf-8'))
                print(data)
                # 获取当前响应片段
                response_fragment = data.get("response", "")
                # 输出当前片段
                print(response_fragment, end="", flush=True)
                # 拼接到完整响应中
                full_response += response_fragment
                # 如果响应完成，退出循环
                if data.get("done", False):
                    print("\n\nResponse completed.")
                    break

        # 记录结束时间
        end_time = time.time()
        # 计算响应时间
        response_time = end_time - start_time
        print(f"\nAPI响应时间: {response_time:.2f} 秒")

        return response_time

    except Exception as e:
        print(f"Error calling API: {e}")
        return None


def get_models_and_servers():
    """
    从数据库获取模型和服务器的 IP + 端口信息
    """
    try:
        # 连接到数据库
        conn = sqlite3.connect('servers.db')
        cursor = conn.cursor()

        # 查询服务器和模型信息
        cursor.execute('''
            SELECT s.ip, s.port, m.model, m.name 
            FROM servers s
            JOIN models m ON s.id = m.server_id
        ''')

        # 获取所有结果
        rows = cursor.fetchall()

        # 关闭数据库连接
        conn.close()

        return rows
    except Exception as e:
        print(f"Error fetching data from database: {e}")
        return []


def main():
    # 获取模型和服务器信息
    server_model_info = get_models_and_servers()

    if not server_model_info:
        print("No data found in the database.")
        return

    # 设置提示词
    prompt = "你好"

    # 循环调用 API
    for ip, port, model, name in server_model_info:
        url = f"http://{ip}:{port}/api/generate"  # 构建 API 地址
        print(f"Calling DeepSeek API with model '{model}' and prompt '{prompt}' at {ip}:{port}...\n")

        # 调用 API
        response_time = delaytest(url, model, prompt)

        # 如果有响应时间，可以选择保存或者记录
        if response_time:
            print(f"Response time for model '{model}' at {ip}:{port}: {response_time:.2f} seconds\n")


if __name__ == "__main__":
    main()
