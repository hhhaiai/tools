import requests
import json
import sqlite3

DB_PATH = "servers.db"  # 替换为实际的数据库路径


def check_ollama(ip, port, server_id, conn):
    """
    请求指定 IP 和端口的 Ollama API，如果请求成功，将模型数据添加到数据库。
    """
    ollama_url = f"http://{ip}:{port}/api/tags"

    try:
        # 发送 GET 请求到 Ollama API
        response = requests.get(ollama_url)

        # 检查响应状态码
        if response.status_code == 200:
            print(f"成功连接到 {ip}:{port}")
            models = response.json().get('models', [])

            if models:
                cursor = conn.cursor()

                for model in models:
                    name = model.get('name')
                    model_name = model.get('model')
                    modified_at = model.get('modified_at')
                    size = model.get('size')
                    digest = model.get('digest')
                    parent_model = model.get('details', {}).get('parent_model', '')
                    format = model.get('details', {}).get('format', '')
                    family = model.get('details', {}).get('family', '')
                    families = ",".join(model.get('details', {}).get('families', []))
                    parameter_size = model.get('details', {}).get('parameter_size', '')
                    quantization_level = model.get('details', {}).get('quantization_level', '')

                    # 将模型数据插入 models 表
                    cursor.execute('''
                        INSERT INTO models (
                            server_id, name, model, modified_at, size, digest, parent_model,
                            format, family, families, parameter_size, quantization_level
                        )
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ''', (server_id, name, model_name, modified_at, size, digest, parent_model,
                          format, family, families, parameter_size, quantization_level))
                    conn.commit()
                    print(f"已将模型 {name} 存储到数据库")

            return True  # 请求成功
        else:
            print(f"请求失败，IP: {ip}:{port}，状态码: {response.status_code}")
            return False  # 请求失败
    except Exception as e:
        print(f"请求过程中发生错误，IP: {ip}:{port}，错误: {e}")
        return False  # 请求失败



