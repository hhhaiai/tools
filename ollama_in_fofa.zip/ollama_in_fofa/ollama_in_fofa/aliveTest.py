import sqlite3
import requests

# SQLite 数据库文件路径
DB_PATH = "servers.db"  # 替换为实际的数据库路径

# 自定义的 check_ollama 函数
def check_ollama(ip, port, server_id, conn):
    """
    检查指定 IP 和端口的服务器是否存活。
    如果存活，返回 True；否则返回 False。
    """
    url = f"http://{ip}:{port}"  # 构造请求 URL
    try:
        # 发送 GET 请求，设置超时时间为 5 秒
        response = requests.get(url, timeout=5)
        # 如果状态码为 200，表示服务器存活
        if response.status_code == 200:
            print(f"服务器 {ip}:{port} 存活")
            return True
        else:
            print(f"服务器 {ip}:{port} 返回状态码: {response.status_code}")
            return False
    except requests.exceptions.RequestException as e:
        # 如果请求失败（超时、连接错误等），表示服务器不存活
        print(f"服务器 {ip}:{port} 请求失败: {e}")
        return False

# 创建数据库连接
conn = sqlite3.connect(DB_PATH)
cursor = conn.cursor()

# 从数据库中读取所有服务器的 IP 和端口
cursor.execute('SELECT id, ip, port FROM servers')
servers = cursor.fetchall()

# 遍历每个服务器，进行存活探测
for server in servers:
    server_id = server[0]
    ip = server[1]
    port = server[2]

    # 调用 check_ollama 函数检查此 IP 是否存活
    if check_ollama(ip, port, server_id, conn):
        print(f"服务器 {ip}:{port} 存活，保留在数据库中")
    else:
        # 如果服务器不存活，从数据库中删除
        cursor.execute('DELETE FROM servers WHERE id = ?', (server_id,))
        conn.commit()
        print(f"服务器 {ip}:{port} 不存活，已从数据库中删除")

# 关闭数据库连接
conn.close()