int register_winsvc(int argc, char *argv[]);
