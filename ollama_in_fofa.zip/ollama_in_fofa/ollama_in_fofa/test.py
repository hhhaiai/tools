import base64
import requests
import sqlite3

# FOFA API 配置
FOFA_EMAIL = "2078681762@qq.com"  # 替换为你的 FOFA 邮箱
FOFA_KEY = "83a41d0167ff4f0faa4d716de0f1c0f2"  # 替换为你的 FOFA API 密钥
BASE_URL = "https://fofa.info/api/v1/search/all"  # FOFA API 地址

# SQLite 数据库文件路径
DB_PATH = "servers.db"  # 替换为实际的数据库路径

# 搜索参数
query = '"Ollama is running" && "HTTP/1.1 200 OK"'  # FOFA 查询语法
fields = "ip,port,country,country_name,region,city,longitude,latitude"  # 更新为所有需要返回的字段
size = 10  # 每次请求的最大结果数（最大 10000）

# 构造请求 URL
params = {
    "email": FOFA_EMAIL,
    "key": FOFA_KEY,
    "qbase64": base64.b64encode(query.encode("utf-8")).decode("utf-8"),  # Base64 编码, 查询语句需要 Base64 编码
    "fields": fields,
    "size": size,
}

# 请求 FOFA API 获取 IP 地址和端口等信息
try:
    # 发送 GET 请求
    response = requests.get(BASE_URL, params=params)

    # 检查响应状态码
    if response.status_code == 200:
        data = response.json()
        if data["error"]:  # 检查是否有错误
            print(f"FOFA 返回错误: {data['errmsg']}")
        else:
            results = data["results"]
            print(f"共找到 {len(results)} 条结果:")

            # 创建数据库连接
            conn = sqlite3.connect(DB_PATH)
            cursor = conn.cursor()

            # 创建表（如果表不存在）
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS servers (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    ip TEXT NOT NULL,
                    port INTEGER NOT NULL,
                    country_code TEXT,
                    country_name TEXT,
                    region TEXT,
                    city TEXT,
                    longitude REAL,
                    latitude REAL
                )
            ''')
            conn.commit()

            # 遍历 FOFA 返回的每个结果，获取 IP 和端口并保存到数据库
            for result in results:
                ip = result[0]
                port = result[1]
                country_code = result[2]
                country_name = result[3]
                region = result[4]
                city = result[5]
                longitude = result[6]
                latitude = result[7]

                # 将结果保存到数据库
                cursor.execute('''
                    INSERT INTO servers (ip, port, country_code, country_name, region, city, longitude, latitude)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ''', (ip, port, country_code, country_name, region, city, longitude, latitude))
                conn.commit()

            # 关闭数据库连接
            conn.close()

    else:
        print(f"请求失败，状态码: {response.status_code}")
        print(f"错误信息: {response.text}")
except Exception as e:
    print(f"请求过程中发生错误: {e}")
