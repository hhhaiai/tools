

class UrlRequest:
    __doc__ = "UrlRequest"

    def __init__(self):
        return

    def requests(self):
        return

    def proxy(self):
        return

    def autoProxy(self):
        return

    def getFakeAgent(self):
        return
