# 报告漏洞

代码的安全扫描

[![Security Status](https://www.murphysec.com/platform3/v31/badge/1720281845524238336.svg)](https://www.murphysec.com/console/report/1720281838695911424/1720281845524238336)

以及

如果你发现了安全问题,请新建[ISSUE](https://github.com/Cl0udG0d/Fofa-hack/issues/new) 报告（疑似）安全漏洞。

您将在 48 小时内收到回复。如果问题得到确认，我们将根据复杂程度尽快发布补丁，但通常会在几天内发布。
