#!/usr/bin/env python
# -*- coding: utf-8 -*-
import os
import sys
import base64
import mmh3
import requests
import codecs
from core.fofaMain import FofaMain
from tookit import config, unit
from tookit.levelData import LevelData
from tookit.outputData import OutputData
from tookit.unit import clipKeyWord, outputLogo

class FofaAPI:
    def __init__(self, authorization=None, debug=False, fofa_key=None):
        """
        初始化 FofaAPI
        :param authorization: FOFA 的 authorization 值（可选）
        :param debug: 是否开启调试模式
        :param fofa_key: FOFA API key值
        """
        config.ROOT_PATH = os.path.dirname(os.path.abspath(__file__))
        if getattr(sys, 'frozen', None):
            dir = sys._MEIPASS
        else:
            dir = config.ROOT_PATH

        if authorization:
            config.AUTHORIZATION = authorization
        if fofa_key:
            config.FOFA_KEY = fofa_key
        config.DEBUG = debug
    
    def search_by_icon_url(self, icon_url, **kwargs):
        """通过图标URL搜索"""
        if icon_url.endswith(".ico"):
            url = icon_url
        else:
            url = icon_url + "favicon32.ico" if icon_url.endswith("/") else icon_url + "/favicon32.ico"
        try:
            _icon = mmh3.hash(codecs.lookup('base64').encode(requests.get(url).content)[0])
            search_key = f'''icon_hash="{_icon}"'''
            return self.search(search_key, **kwargs)
        except:
            print(f"icon url {url} 访问错误")
            return None

    def search_by_icon_file(self, icon_file, **kwargs):
        """通过图标文件搜索"""
        if os.path.exists(icon_file):
            with open(icon_file, 'rb') as f:
                _icon = mmh3.hash(codecs.lookup('base64').encode(f.read())[0])
                search_key = f'''icon_hash="{_icon}"'''
                return self.search(search_key, **kwargs)
        return None

    def search_by_base64(self, base64_str, **kwargs):
        """通过base64编码的关键字搜索"""
        try:
            search_key = base64.b64decode(base64_str).decode('utf-8')
            return self.search(search_key, **kwargs)
        except Exception as e:
            print(e)
            return None
    
    def search(self, keyword, output_file="fofaHack.txt", time_sleep=3, end_count=100, 
              level="1", proxy=None, proxy_type="http", timeout=180, fuzz=False):
        """
        搜索 FOFA
        :param keyword: 搜索关键字
        :param output_file: 输出文件名
        :param time_sleep: 每页等待时间
        :param end_count: 获取数量
        :param level: 获取等级 1-3
        :param proxy: 代理地址，格式如 '127.0.0.1:7890'
        :param proxy_type: 代理类型，支持 http/socks4/socks5
        :param timeout: 超时时间
        :param fuzz: 是否启用 fuzz 模式
        :return: 输出文件路径
        """
        outputLogo()
        search_key = clipKeyWord(keyword)
        level_data = LevelData(level)
        output_format = output_file.split('.')[-1] if '.' in output_file else 'txt'
        output_name = output_file.rsplit('.', 1)[0]
        filename = f"{output_name}.{output_format}"
        
        # 检查并删除已存在的文件
        if os.path.exists(filename) and os.path.exists(f"final_{filename}"):
            os.remove(filename)
            os.remove(f"final_{filename}")
        
        output_data = OutputData(filename, level, pattern=output_format)
        
        if proxy:
            config.IS_PROXY = True
            config.PROXY_SINGLE = True
            config.PROXY_ARGS = proxy
            config.PROXY_TYPE = proxy_type
        
        fofa = FofaMain(
            search_key=search_key,
            inputfile=None,
            filename=filename,
            time_sleep=time_sleep,
            endcount=end_count,
            level=level,
            level_data=level_data,
            output=output_format,
            output_data=output_data,
            fuzz=fuzz,
            timeout=timeout,
            is_proxy=config.IS_PROXY
        )
        
        return fofa.start()

# 使用示例
if __name__ == '__main__':
    # 初始化
    fofa = FofaAPI(debug=True)
    
    # 关键字搜索
    fofa.search("Ollama is running")
    
    # 图标搜索
    fofa.search_by_icon_url("https://example.com")
    
    # 图标文件搜索
    fofa.search_by_icon_file("favicon.ico")
    
    # Base64搜索
    fofa.search_by_base64("dGhpbmtwaHA=")
    
    # 高级搜索（带代理）
    fofa.search(
        keyword="Ollama is running && before=\"2025-02-08\"",
        output_file="ollama_results.txt",
        time_sleep=5
    )