# Fofa-hack

![Fofa-hack](./images/logo.png)

> 非付费会员,fofa数据采集工具

fofa对于爬虫搜索限制越来越严格,该项目不会再进行更新(当然也不会删除)

如果有后来者想要开发fofa的爬虫工具可以参考该项目

其实如果想要从代码角度来绕过的话还是可行的,比如添加打码的第三方库,内置代理池等等,但是这样的话对于使用者来说其实就存在门槛并且效果也不算好

原本的[README](./README.md)

感谢这个项目的贡献者们


Non-paying members,fofa data collection tool

fofa for crawler search more and more strict restrictions, the project will not be updated (of course, will not be deleted)

If there are later want to develop fofa crawler tool can refer to the project!

In fact, if you want to bypass from the code point of view or feasible, such as adding third-party libraries for coding, built-in proxy pools, etc., but then there is actually a threshold for the user and the effect is not good!

The original [README](./docs/EN_README.md)

Thanks to the contributors of this project


<table>
<tr>
    <td align="center">
        <a href="https://github.com/Cl0udG0d">
            <img src="https://avatars.githubusercontent.com/u/45556496?v=4" width="100;" alt="Cl0udG0d"/>
            <br />
            <sub><b>潘一二三</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/wanswu">
            <img src="https://avatars.githubusercontent.com/u/49047734?v=4" width="100;" alt="wanswu"/>
            <br />
            <sub><b>Wans</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/tastypear">
            <img src="https://avatars.githubusercontent.com/u/1382667?v=4" width="100;" alt="wanswu"/>
            <br />
            <sub><b>tastypear</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/KawaiiSh1zuku">
            <img src="https://avatars.githubusercontent.com/u/51824296?v=4" width="100;" alt="wanswu"/>
            <br />
            <sub><b>KawaiiSh1zuku</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/Valdo-Caeserius">
            <img src="https://avatars.githubusercontent.com/u/148833225?v=4" width="100;" alt="wanswu"/>
            <br />
            <sub><b>Valdo-Caeserius</b></sub>
        </a>
    </td>
    <td align="center">
        <a href="https://github.com/10cks">
            <img src="https://avatars.githubusercontent.com/u/47177550?v=4" width="100;" alt="wanswu"/>
            <br />
            <sub><b>10cks</b></sub>
        </a>
    </td>
<td align="center">
        <a href="https://github.com/fireinrain">
            <img src="https://avatars.githubusercontent.com/u/14249262?v=4" width="100;" alt="fireinrain"/>
            <br />
            <sub><b>fireinrain</b></sub>
        </a>
    </td>
</tr>
<tr>
<td align="center">
        <a href="https://github.com/Arc-2023">
            <img src="https://avatars.githubusercontent.com/u/64178177?v=4" width="100;" alt="fireinrain"/>
            <br />
            <sub><b>Arc-2023</b></sub>
        </a>
    </td>
</tr>
</table>

广告时间 - 也欢迎大家加入我的纷传,会在里面更新安全开发相关的内容~
<td align="center">
        <img src="./images/738473188fb95c76d0b8055ec869d37.jpg" width="300;" alt="fireinrain"/>
        <br />
</td>
